export const firebase = {
  firebase: {
    apiKey: 'AIzaSyBUtCNlDsorif5FmUKiFtWxrrLF-QcfKuI',
    authDomain: 'fir-contact-c6ceb.firebaseapp.com',
    databaseURL: 'https://fir-contact-c6ceb.firebaseio.com',
    projectId: 'fir-contact-c6ceb',
    storageBucket: 'fir-contact-c6ceb.appspot.com',
    messagingSenderId: '512941871127',
    appId: '1:512941871127:web:51fd458ae916cd84894c52',
  },
};
